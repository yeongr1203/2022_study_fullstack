<?php error_reporting(E_ALL); ini_set("display_errors", 1); ?>


<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
   
    $str = "PHP 웨프로그래밍";
    print "str[0] : " . $str[0] . "<br>";
    print "str[4] : " . $str[4] . $str[5] . $str[6] . "<br>";
    print $str . "<br>";

    
    $str1 = "http://www.php.edu/testurl.html?name=kim&age=28";
    // 단순한 문자열
    $str2 = parse_url($str1);   // 객체, 즉 배열로 바꾸면 배열안에 host만. 정의한 배열만 뽑아낼 수 있음.
    print "SCHEME : " . $str2["scheme"] . "<br>";
    print "HOST : " . $str2["host"] . "<br>";
    print "PATH : " . $str2["path"] . "<br>";
    //var_dump($str2);


    error_log("test", 3, "./err.log");


    print "query : ". $str2["query"]. "<br>";
    // 문자열을 잘라서 가져오는 게 아니라 배열로 만들어 주는것이라서 값을 각각 가져오는것이 편함.


    // str1에서 쿼리스트링.
    parse_str($str2["query"], $output);     // & 기준으로 값을 나눴을 것.
    // name = Kim, age = 28;   
    print "이름 : ";
    print $output["name"];
    print "<br>";
    $sitename = "php웹이즈프리";
    echo substr($sitename, 0, 6) . "<br>";
    // substr 문자를 3자리까지 찍힘.
    echo mb_substr($sitename, 0, 1) . "<br>";
    echo mb_strlen($sitename) . "<br>";
    // echo strlen($sitename) . "<br>";
    // strlen도 있음. 1글자 3자리, 3*8글자 = 18, 결과값 : 18
    printf("나이 %02d, 키 %.2f <br>", 8, 173.1212);     // 8, 173.1212를 앞에 각 키에 값을 넣겠다 라는 뜻.
    // 나이 다음에 빈칸2개차지하고 2번째자리에 8이 들어감. 숫자포함한 칸의 갯수.
    // 숫자앞에 -가 없으면 왼쪽 정렬. -는 오른쪽 정렬


    $date = "2017 1 13";
    // $date = "2017/1/13";    // 이것도 가능.
    // $date = "2017_1_13_10";    // 이렇게 4개일경우, 아래처럼 3가지 일땐 앞에서부터 3개의 값만 대입되어 나타남.
    // sscanf($date, "%d/%d/%d", $year, $mon, $day);
    sscanf($date, "%d %d %d", $year, $mon, $day);
    // sscanf  값들을 정수형으로 변수에 모두 대입. 
    // 값을 뽑아내고 싶을때 사용하는 것.
    print $year . "<br>";
    print $mon . "<br>";
    print $day . "<br>";


    $str4 = "나이는 12살입니다.";
    // 구분자를 빈칸으로 함. 타입만 달라도 구분이 됨. 
    // 나이는 / 12 /  살입니다.
    // 12라는 값만 뽑아내고 싶을 떄. 그 뽑아내려는 값 앞부분까지는 나타내야함.
    // 꼭 sscanf아니더라도 뽑아 낼 수 있음.
    sscanf($str4, "%s %d %s", $strAge, $decAge, $strAge2);  // $f는 실수까지 뽑아낼 수 있음.
    print $strAge . "<br>";
    print $decAge . "<br>";
    print $strAge2 . "<br>";

    
    $str5 ="나이는 121212살입니다.";
    sscanf($str5, "%s %d", $strAge5, $decAge5 );
    print $strAge5 . "<br>";
    print $decAge5 . "<br>";
?>    
</body>
</html>