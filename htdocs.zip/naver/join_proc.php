<?php
    include_once 'db/db_user.php';

    $uid = $_POST['uid'];
    $upw = $_POST['upw'];
    $confirm_upw = $_POST['confirm_upw'];
    $nm = $_POST['nm'];
    $gender = $_POST['gender'];
    $birth = $_POST['birth'];
    $phone = $_POST['phone'];
    $addr = $_POST['addr'];
    $email = $_POST['email'];

    $nn = [
        "uid" => $uid,
        "upw" => $upw,
        "nm" => $nm,
        "gender" => $gender,
        "birth" => $birth,
        "phone" => $phone,
        "addr" => $addr,
        "email" => $email,
    ];
    $result = ins_proc($nn);

    if ($result) {
        header("location: login.php");        
    }

?>