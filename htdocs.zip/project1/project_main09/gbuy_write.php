<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="ggform.css">
</head>
<body>
    <H2>공동구매 폼</H2>
    <form action="gbuy_write_proc.php">
        <fieldset>
        <label><div>제목</div><input type="text" name="" placeholder=""></label><hr>
        <label><div>식물명</div><input type="text" name="" placeholder=""></label><hr>
        <label><div>가&nbsp&nbsp&nbsp격</div><input type="text" name="" placeholder=""></label><hr>
        <label><div>목표구매량</div><input type="text" name="" placeholder=""></label><br><hr>
        <textarea class="ctnt" name="" placeholder="설명을 적어주세요"></textarea><br>
        <input class="" type="file" name=""><hr>
        <label><div>계좌번호</div><input type="text" name="acnum"></label><hr>
        <input type="date" name="" id=""> ~ <input type="date" name="" id="">
        <input class="button" type="submit" value="작성">
        <!-- 관리자만 가능, 클릭하면 상단으로 올라감--><input class="button" type="button" value="끌올">
        </fieldset>
    </form>
</body>
</html>