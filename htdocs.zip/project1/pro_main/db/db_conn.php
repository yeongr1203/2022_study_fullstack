<?php
    define("db_host", "localhost");
    define("db_user", "root");
    define("db_password", "506greendg@");
    define("db_db", "project");
    define("PORT", "3306");

    function get_conn(){
        return mysqli_connect(db_host, db_user, db_password, db_db, PORT);
    }