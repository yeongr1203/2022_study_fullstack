<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>메인페이지</title>
  <link rel="stylesheet" href="css/main.css">
  <script src="https://kit.fontawesome.com/35a40717bb.js" crossorigin="anonymous"></script>
</head>
<body>
  <div id="container">
    <header id="top"><!--로고 누르면 메인페이지로 이동, 해당 부분은 항상 top에 위치-->
      <div class="top_logo"><a href="main_page.php"><i class="fa-solid fa-seedling fa-3x" id="logo_icon" style="color:#fff"></i></a></div>
      <div class="lg_join"><!--로그인 상태일때는 내글보기/내정보/로그아웃-->
      <?php if(isset($_SESSION["login_user"])){ ?>
        <a href="info_page.php"><button>INFO</button></a>
        <a href="logout.php"><button>LOGOUT</button></a>
      <?php } else { ?>
        <a href="login_page.php"><button>LOGIN</button></a>
        <a href="join_page.php"><button>JOIN</button></a>
      <?php } ?>
      </div>
    </header>

    <div id="bn">
      <div id="bn_left">
        <div class="left_txt">
          <p>Hello, Gardener!</p>
          <h1>베란다 가든에 어서오세요.</h1>
          <h4>반려식물을 모시는 식집사들의 친목활동, 정보공유를 위한 커뮤니티입니다.</h4>
        </div>

        <div id="search_bar">
          <input type="text" placeholder="무엇이든 물어보세요">
          <i class="fa-solid fa-magnifying-glass"></i>
        </div>
      </div>
    </div>
    
    <div id ="main_contents">
      <div id="board_contents">
          <div id="gell_box">
            <div class="board_title">
              <h4>우리집 초록이를 자랑해요</h4>
              <p><a href="#">더보기</a></p>
            </div>  
            
            <div id="box_inner">
              <ul class="box_list">
                <li class="box_list_item">
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>

                <li>
                  <img src="img/icon1.png"><!--최신글 이미지-->
                  <div class="info">
                    <span class="info_title"> 새싹이 났어요~<!--게시글 제목--></span>
                    <span class="user_name"> 작성자 </span>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div id="total_board">
            <div class="board_title">
              <h4>전체글보기</h4>
              <p><a href="board_list.php">더보기</a></p>
            </div>

            <table>
              <tr>
                <td>게시판이름</td>
                <td>게시글 제목</td>
                <td>작성자</td>
                <td>작성일시</td>
                <td>조회수</td>
              </tr>
            </table>
          </div>
      </div>
      
      <div id="main_side">
        <div id="lg_side">
          <div class="user_ins">
            <!--로그인 상태면 유저정보/ 아니면 "유저정보가 없습니다. (로그인/회원가입)"-->
          </div>
        </div>
          
        <nav id="menu_bar">
          <ul class="main_menu">
            <li>
              <span>필독공지</span>
              <ul class="sub_menu">
                <li><a href="notice_board.php">공지사항</a></li>
                <li><a href="#">건의사항</a></li>
              </ul>
            </li>

            <li>
              <span>가든 가꾸기</span>
              <ul class="sub_menu">
                <li><a href="#">가든용품</a></li>
                <li><a href="#">화원 / 마켓 정보</a></li>
                <li><a href="tip_board.php">나만의 꿀팁</a></li>
                <li><a href="#">식물이 아파요</a></li>
                <li><a href="#">묻고 답하기</a></li>
              </ul>
            </li>

            <li>
              <span>자랑해요</span>
              <ul class="sub_menu">
                <li><a href="img_board.php">반려식물</a></li>
                <li><a href="#">우리집 정원</a></li>
                <li><a href="#">성장일기</a></li>
              </ul>
            </li>

            <li>
              <span>식물집사</span>
              <ul class="sub_menu">
                <li><a href="#">식집사님들의 일상</a></li>
                <li><a href="#">수다방</a></li>
              </ul>
            </li>
            <li>
              <span>나눔해요</span>
              <ul class="sub_menu">
                <li><a href="#">나눔/교환</a></li>
                <li><a href="#">나눔/교환 후기</a></li>
                <li><a href="#">공동구매</a></li>
                <li><a href="#">공동구매 후기</a></li>
              </ul>
            </li>
            
          </ul>
        </nav>
      </div>

    </div>


    <div id="footer">
      <p>식집사들의 이야기 https://www.veranda.com </p>
      <p>VERANDA GARDEN</p>
    </div>
  </div>
</body>
</html>