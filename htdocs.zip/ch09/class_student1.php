<?php
    // Access Modifier => 접근지시어 (접근할 수 있는 범위를 지정한다.)
    // 접근제어 지시자
    // 접근지시어 
    // 접근제어자
    // Java : private default protected public
    // php : public, protected, private

    // 틀 만듬.
    class Student {     
        public $cnt = 3;    // 함수가 밖에 중복으로 있을때,예시.
        //  객체 만드는 친구는(클래스명) 무조건 대문자로 시작.
        public $studentId;       // public 접근제어자.
        public $studentName;
        // 속성에서 2개를 저장. // 여기까지가 멤버 필드

        public function printStudent($id, $name) {      // 외부로 들어오는 것을 받아서 출력하는 것.
            print "ID : ${id} <br>";
            print "Name : ${name} <br>";
           // 멤버 메소드.

        // 무한루프 도는 형식.
        // $this->printStudent("","");

        // 밖에 같은 함수명이 있으면.
        if($this->cnt === 0) {
            return;
        }
        $this->cnt--;
        // $this->printStudent("111", "222");  // this는 함수안에서만 불러올때. 주소값.printStudent와 같은것 그래서 안에서 찾는것.
        printStudent("111", "222"); // 외부호출
    }
    
    //선생님이 수정한다면.
    // public function printStudent() {      // 외부로 들어오는 것을 받아서 출력하는 것.
    //     print "ID : $this->studentId <br>";
    //     print "Name : $this->studentname <br>";
    // }
}
    
    //질문 만약 밖에도 같은 함수가 있다면.
    function printStudent($id,$name) {
        print "ddd: ${id}, {$name}";
    }
    // 전역-> printStudent("kkk","ggg");    // 전역이라면 전역.으로 작성해야함.
    printStudent("kkk","ggg");    // 전역이라면 전역.으로 작성해야함.


    // 객체생성
    $obj = new Student; //Student는 클래스명을 넣음. 인스턴스(student) 주솟값이 복사되어 obj에 넘어간다.
    // 즉, 객체주소값이 담긴다. 접근이 된다는 것은. 속성은 읽거나 가져오거나 변경할 수 있고, 메소드는 호출할 수 있다.
    
    $obj->studentId = 20171234;         // 자바스크립트는 주솟값. (주솟값 접근방법)이지만, php는 ->이걸로 사용.
    $obj->studentName = "Alice";

    // $obj->printStudent();    // 굳이 지금처럼 밖에서 넣지 않을때, 작성.
    // 외부에서 값을 보냄
    $obj->printStudent($obj->studentId,$obj->studentName);  // 저장된 값을 저장되어 값을 가져오는 것.
    // 메소드 호출 (20171234, Alice) => 보이드메소드(함수 내에도 리턴이 없음.)

// php배열과 차이점.
// 배열은 메소드 가질수 없고, 객체는 메소드 가질 수 있음.
// 배열은 접근할수있는 값을 조정할 수 없다. 객체는 가능.
// 단순한건 배열 (같은 값, 같은타입일 떄), 복잡한 건 객체.
// 객체만 유일하게 혼자서 움직일 수 있는 애를 만들 수있다.
// 나머지는 함수를 이용해서 움직일 수있다.
// 값전달용은 배열, 객체 모두 가능. =>value.
// 객체는 함수를 가질 수 있다고 생각하면 됨.