<?php

    class People {  // 부모

        protected $name;
        protected $age;
        /*
            만약 private이였다면, 지금 여기 class에서만 사용하지만, 
            protected는 상속받기 때문에 외부에서도 사용이 가능하다.
        */

        // function __construct() {
        //     print "나는 People이요. <br>";
        // }

        function printPeople(){
            print "Name : {$this->name}<br>";
            print "Age : {$this->age}<br>";
        }
    }

    class Student extends People {      // Student(자식이)가 People을 참조한다.
        private $studentId;
        
        function __construct($name,$age, $studentId) {
            print "나는 Student요. <br>";
            $this->name = $name;
            $this->age = $age;
            $this->studentId = $studentId;
        }
        function printStudent(){
            print "- studnet -<br>";
            // $this->printPeople();    // 오버라이딩 되어 있을때, this와 parent와 차이점이 생김. 
            // (this는 내 주솟값에서 제일 가까운데서 찾음 그래서 같은 class안에서 먼저 찾음.)
            // parent에서 오버라이딩일경우에는 내 부모에서 부터 가지고 오는 것. 그래서 class안에 있다고 해서 바뀌지 않음.
            parent::printPeople();   // 내 부모에있는 printPeople()을 실행하겠다. 라는 뜻. 구분해서 사용할 때가 있을 수있음.
            print "Id : {$this->studentId} <br>";
        }

        // 오버라이딩
        function printPeople()
        {
            print "Student에 있는 Print People <br>";
        }
        /* 오버라이딩 
            : 덮어쓰기 부모에 있는 기존 메소드를 사용하지 않고, 내가 새롭게 정의해서 쓰겠다 하는것.
        */
    }
    /*  $stu1 = new Student("홍길동", 21, 1010); 여기에서 new Student("홍길동", 21, 1010); 이부분은
        student를 객체화 시키는데, 이 객체는 호출 했을때, 본인이 찾는것이 자기 자신에게 없으면,
        부모를 참조, 그래서 메모리에는 부모가 먼저 올라감.부모 다음으로 student가 메모리에 올라감.
        즉, 메인은 student, 먼저 메인에서 찾고 없으면 부모로 가서 찾고, 그 찾은 장소에 저장이 된다. 
        찾는 것이 부모에 있을 경우 그 소스가 자식에게 가는 것이 아님. 참조한 부모로 가서 찾아서 그 값을 찾아서 해결. 부모에게도 없으면 에러.
        부모의 값이 복사되어 자식에게 주는 것이 절대 아님!!
    */
    $stu1 = new Student("홍길동", 21, 1010);    
    $stu1->printPeople();
    print "---------<br>";
    $stu1 -> printStudent();




    class Professor extends People {
        private $office_No;

        function __construct($name,$age,$no) {
            $this->name = $name;
            $this->age = $age;
            $this->office_No = $no;
        }
        function printProfessor() {
            print "- Professor -<br>";
            $this -> printPeople();
            print "Office_NO : ".$this-> office_No . "<br>";
        }
    }
    
    class Staff extends People {
        private $title;

        function __construct($name,$age,$title) {
            $this->name = $name;
            $this->age = $age;
            $this->title = $title;
        }

        function printStaff(){
            print "- Staff -<br>";
            $this -> printPeople();
            print "Title : ".$this-> title . "<br>";
        }
    }


    // $object1 = new Student("Lee", "21", "20170123");
    // $object2 = new Professor("Kim", "42", "107");
    // $object3 = new Staff("Park", "37", "chief");

    // $object1->printStudent();
    // print "<br>";
    // $object2->printProfessor();
    // print "<br>";
    // $object3->printStaff();
    // print "<br>";