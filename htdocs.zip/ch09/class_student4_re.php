<?php

    class Student {    
        private $studentId;    
        private $studentName;  

        // function __construct() {
        //     return $this;
        // }

        public function getStudentId(){ 
            return $this->studentId;   
        }

        public function getStudentName(){
            return $this->studentName;
        }

        public function setStudentId($studentId) { 
            $this -> studentId = $studentId;
            return $this;
        }

        public function setStudentName($studentName) {
            $this -> studentName = $studentName;
            return $this;
        }


        public function printStudent() {     
            print "ID : {$this->studentId} <br>";
            print "Name : {$this->studentName} <br>";       
        }
    }
    
    $obj = new Student;   
    print "1번째 : ".$obj->setStudentId(1122)->getStudentId()."<br>";

    $obj2 = new Student;
    print $obj2->setStudentID(8888)->getStudentId()."<br>";
    print "2번쨰 : ".$obj->getStudentId()."<br>";

