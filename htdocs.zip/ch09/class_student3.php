<?php
        // public 완전 오픈.
        // private은 class 안에서만 사용가능.
        // protected 는 같은 네임스페이스까지 가능.
        
    class Student {      
        // 상수만 public 가능, 나머지는 전부 은닉.private
        private $studentId;       
        private $studentName;

        public function printStudent($id, $name) {     
            print "ID : ${id} <br>";
            print "Name : ${name} <br>";       
        }
    }
    
    // 중괄호 벗어난 곳에선 사용할 수 없다 => 은닉화, 캡슐화.
    $obj = new Student;   
    // $obj -> studentId=111;  // 이렇게 접근하면 에러가 터짐.
    $obj->printStudent( 12122, "홍길동");  