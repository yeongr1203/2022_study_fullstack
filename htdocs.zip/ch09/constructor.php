<?php
    class Fruit {       // 값을 저장안하고 쓰는 객체???
        private $name;
        private $color;
        private $price;

        /*

            값을 먼저 넣는 방법. => 생성자 통해서. setter메소드를 통해서 
            프라이빗한 값을 외부로 가지고 오는 것(빼내는 방법) => getter메소드를 통해서
        */

        // 생성자함수
        // php 에서 __(언더바언더바)는 특별한 애.
        // __construct 는 function앞에 public이 들어감. (즉, 디폴트값이 public, 멤버메소드에 자동으로 들어감.)
        function __construct($name, $price, $color) {   // private 필드(은닉화된 멤버필드)에 은닉화된 값을 먼저 넣고 시작할때 
            $this->name = $name;
            $this->color = $color;
            $this->price = $price;
        }

        public function print_fruit() {
            print "Name : {$this->name}<br> ";
            print "Color : {$this->color}<br> ";
            print "Price : {$this->price}<br> ";
        }
        // 만약 게터메소드가 있다는 말은 여기서 값을 빼서 밖으로 빼 줄 수도있다라는 뜻.
    }   // 멤버필드에서 유일하게 꺼내쓸수 있는 방법은 여기 안이고, 그 외에는 은닉화를 시켜야한다.?

    $apple = new Fruit("Apple", 1000, "red");
    $banana = new Fruit("Banana", 500, "yellow");   // 만약 ""빈칸도 메모리 사용한다. 적용이 됨.

    $apple -> print_fruit();
    $banana -> print_fruit();