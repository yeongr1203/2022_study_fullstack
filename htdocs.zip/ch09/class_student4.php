<?php
        // 은닉화 한다면, 겟터 셋터 작성. 필수!
        // 상수만 public, 나머지는 private  

    class Student {    
        private $studentId;     // getter만듬 (getStudentId) 
        private $studentName;   // setter만듬 (setStudentID)

        function __construct() {
            return $this;
        }

        // getters = 읽기
        public function getStudentId(){ // 게터는 파라미터 값이 없음. 
            return $this->studentId;    // this 필수.   // studentId의 겟터
            // 파라미터가 없는 대신 리턴이 있음.
        }

        // studentname의 겟터와 셋터 만들기.
        public function getStudentName(){
            return $this->studentName;
        }

        // setters  = 쓰기
        public function setStudentID($studentId) {  // 외부에서 들어오는 Id값을 넣어와야하기때문에 파라미터 필요.
            $this -> studentId = $studentId;
            // 파라미터가 있는 대신에 리턴이 없음.
        }

        public function setStudentName($studentName) {
            $this -> studentName = $studentName;
        }


        public function printStudent() {     
            print "ID : {$this->studentId} <br>";
            print "Name : {$this->studentName} <br>";       
        }
    }
    
    $obj = new Student;   
    // $obj -> studentId = 111;  // 이렇게 접근하면 에러가 터짐.
    $obj->setStudentID(1122);
    // print "1번쨰 : ".$obj->getStudentId(1122)->getStudentId()."<br>";
    $obj->setStudentName("신사임당");
    $obj->printStudent();

    // $obj2 = new Student;
    // print $obj2->setStudentID(8888)->getStudentId()."<br>";
    // print "2번쨰 : ".$obj->getStudentId()."<br>";

    


    /*
    
    getters, setters 만드는 이유. 
        $obj -> studentId = 111;  이렇게 값을 넣고, 읽을 수 없음.
        private은 은닉화로 함수(클래스) 안에서만 작동되는 것이기 때문에 사용하려면
        게터 세터를 퍼블릭화 하여 작성. 그러면 외부로부터 값을 불러오거나 사용할 수 있음.
    
    */