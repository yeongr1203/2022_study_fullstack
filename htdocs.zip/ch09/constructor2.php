<?php
    // 멤버 메소드가 없는 클래스는 상수만 만들어 쓰는 필드만 작업할 때 이후는 없음.
    // 클래스는 설계도, 문서라 생각하면 됨.즉,  내가 객체가 된다면!! 이라는 것. 
    class Fruit {      
        // 클래스안에서 메소드 아닌 애들 => 멤버필드 (즉, 멤버 상수/멤버 변수를 멤버필드라고 부름)
        private $name;  // 얘들은 멤버필드 or 프로퍼티
        private $color;
        private $price;
        public const DDD = 'ddd';   // 얘들은 상수, 상수까지 해서 멤버필드~
        
        
        // 기본적으로 자동으로 넣어줌. 그래서 작성안해도 됨. ()밑에 빨간줄 뜨는데 보기 싫으면 넣으면 됨. 결과는동일함.
        function __construct() {
            return $this;
        }

        // 멤버 메소드 => 클래스 안에 있는 메소드를 멤버 메소드라 함. 그래서 아래 모든 메소드는 멤버 메소드.
        public function print_fruit() {
            print "Name : {$this->name}<br> ";
            print "Color : {$this->color}<br> ";
            print "Price : {$this->price}<br> ";
        }

        /* setter메소드 */
        public function setName($name) {
            $this->name = $name;
            return $this;
        }

        public function setColor($color) {
            $this->color = $color;
            return $this;
        }

        public function setPrice($price) {
            $this->price = $price;
            return $this;   // 세터에서 리턴해주기때문에 객체 밖에서도 객체생성할 수 있다.
        }
} 

// 필요한 값만 뽑아서 객체를 생성하고 싶을 때,

$apple1 = (new Fruit)->setName("사과");
$apple1->print_fruit();

// 아래가 작성하기 제일 괜찮음.
// $apple2 = (new Fruit())->setColor("파란")->setPrice(1000);   // 아래처럼 작성도 함.
$apple2 = (new Fruit)
            ->setColor("파란")
            ->setPrice(1000);
$apple2->print_fruit();

// 세터에서 리턴이 없다면 아래처럼 작성.
$banana1 = new Fruit;
$banana1 -> setColor('노랑');
$banana1-> setPrice(2000);
$banana1 -> print_fruit();

/*

객체, 인스턴스 같다 (미묘한 차이가 있지만 나중에 잘 알때 알면됨.)
멤버필드
프로퍼티 => 속성.// 멤버필드로 인식하면됨.  private $name; 에서 $name을 뜻함.
메소드
객체 안에 있으면 메소드, 밖에있으면 function
즉, class객체안에 있기때문에 안에 있는것들은 메소드, 
    객체 밖에 있다면 function(함수). 객체안에 안감싸져 있으면 함수다!

*/



