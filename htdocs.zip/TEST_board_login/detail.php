<?php

    include_once 'db/db_board.php';
    session_start();
    $login_user = $_SESSION["login_user"];
    
    $i_board = $_GET['i_board'];
    $param = [
        "i_board" => $i_board
    ];
    $i_user = sel_board($param)['i_user'];
    $title = sel_board($param)['title'];
    $nm = sel_board($param)['nm'];
    $created_at = sel_board($param)['created_at'];
    $ctnt = sel_board($param)['ctnt'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$title?></title>
</head>
<body>
    <div><a href="list.php">리스트</a></div>
    <?php if($login_user["i_user"] === $i_user) { ?>
    <div>
        <a href="mod.php"><button>수정</button></a>
        <a href="del.php"><button>삭제</button></a>
    </div>
    <?php } ?>
    <div>제    목 : <?=$title?></div>
    <div>글 쓴 이 : <?=$nm?></div>
    <div>등록일시 : <?=$created_at?></div>
    <div>내   용 : <?=$ctnt?></div>
</body>
</html>