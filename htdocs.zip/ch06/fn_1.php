<?php

    // 비void 함수
    function sum($n1, $n2){  //($n1,$n2) 뭐가 들어올지 모름 = 값이 언제든 변할 수 있어서 매개변수.
        return $n1 + $n2;
    }

    // void 함수 == 덜유연할 뿐, 쓰이기는 쓰임.
    function void_sum($n1,$n2){
        print "sumsum : ".$n1 + $n2."<br>";
    }
    $n1 = 10;
    $n2 = 20;

    void_sum($n1, $n2); //보이드함수는 이렇게 표현해야 한다. 
    void_sum($n1, $n2); //다만 리턴해준 값을 쌩깠을 뿐.

    //보이드 함수는 호출하면 끝. 그 다음이 없음.
    // 즉 function void_sum 안에서만 나옴.

$result = sum($n1, $n2);
print "썸썸 : ".sum($n1, $n2)."<br>";
print "썸 : ".$result."<br>";
print "sum : ".$result."<br>";
print "sum*2 : ".($result*2)."<br>";


// 함수를 최대 필요한 

