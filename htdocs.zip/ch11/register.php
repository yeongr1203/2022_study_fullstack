<?php
    session_start();
    // 스타트는 한번만 실행되면 계속 실행이 됨.
    $_SESSION['var1'] = "v1";
    $_SESSION['var2'] = "v2";
    // 만약 위에 var1,2 모두 실행 되고 2를 주석처리 저장하고 실행 해도
    // 이미 한 번 보냈기 때문에 그대로 실행이 됨.

    // unset($_SESSION['var2']);
    // 세션 없애는 것.
    echo $_SESSION['var1'], "<br>";
    echo $_SESSION['var2'], "<br>";

    // 세션은 한 번 보내면 남아 있어서 그대로 나타남, 
    // 하지만 만약 세션 값을 3로 바꾼다면 바꾼 값이 나타남.
?>
<a href="session_destroy.php">register</a>
<!-- 

    세션이 출력이 되고 a태그를 누르면 페이지 넘어감.

    디스트로이 없이 바로 여기에서 confirm페이지로 넘어가면 var 값들이 
    실행되어 나타남.
    

 -->