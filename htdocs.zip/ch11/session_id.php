<?php

    //세션 아이디 확인방법.
    session_start(); 
    // 앞의 세션을 불러 올경우에는 반드시 세션스타트 넣어줘야 아이디 값을 알 수 있음.
    
    // 세션 ID값을 변경하려면 아래처럼 작성.
    // session_regenerate_id(true);       // 세션 ID값을 변경.

    echo "Session ID : ", session_id();
    // 지금 사용하고 있는 세션의 아이디를 알 수 있음.

