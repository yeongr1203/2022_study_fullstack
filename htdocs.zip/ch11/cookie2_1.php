<?php
    $cookie_key = "aaa";
    setcookie("cookie_key", "한국");   // 응답할때 셋팅하라는 것.
    echo "Country : ", $_COOKIE[$cookie_key], "<br>";
    // 서버의 메모리에 리퀘스트에 _cookie['aaa']=한국 값을 줌.
    
    $_COOKIE['cookie_key'] = "UK";  // 이렇게 사용하면 안됨.
    // 쿠키 값을 바꾸는 방법은 항상 상단처럼 해야함.
    // 만약 변경하고 싶다면 변수로 변경해서 사용할 것.
    /*  변수로 사용해서 할 때, 작성예시.
    $country = $_COOKIE[$cookie_key];
    $country = 'UK';
    */

    echo "Country : ", $_COOKIE[$cookie_key], "<br>";
    // 브라우저에 있는 한국이 UK로 변경이 된 것은 아님.
    
    /*
    unset($_COOKIE['country]);
    setcookie("country");    
    */
    echo "Country : ", $_COOKIE[$cookie_key], "<br>";
?>