<?php

$arr = array();        //이 배열에 최대로 넣을 수 있는 값은 5개까지.
// 1에서 8까지 랜덤 수를 돌려 중복 없이 최대 5개의 값을 구하기.

// $val = rand(1,8);  // 작성해주심. 나올 수 있는 경우의 수는 8개, 총 8개의 경우의 수가 있다.
// 중복되지 않는 랜덤한 값을 넣으시오.

for($i=0; $i<5; $i++){
    $val = rand(1,8);   // 랜덤값을 먼저 뽑아 두고 그 값으로 중복된 것을 비교해야하기 때문에
    // 안에 있다면 계속 중복된 값이 나오면 계속 돌아가기 때문에.
    // 중복된게 있는지 없는지 구분 먼저해주기.
    // $is_duplication 사용했음.
    $is_duplication = 0; // 0: 중복X, 1: 중복O
    for($z=0; $z<count($arr); $z++){
        if($arr[$z] === $val ){ // 중복이라면 1로 표현해주기.
            $is_duplication = 1; 
            break;                  // 중복이기때문에 for문을 종료시켜주기.   // 안해줘도 상관은 없다.
        }
    }
    if($is_duplication) {   // $is_duplication이 1일때,
        $i--;
    }else{  // $is_duplication 값이 아닐 경우를 말함. 
        // 즉, 중복이 아니었다면 값을 넣어줘야한다.
        array_push($arr, $val); //중복 아닐 경우 값을 넣어주는 식.
    }
}
print_r($arr);

// 주석 없이.
for($i=0; $i<5; $i++){
    $val = rand(1,8);
    $is_duplication = 0;
    for($z=0; $z<count($arr); $z++){
        if($arr[$z] === $val) {
            $is_duplication = 1; 
            break;
        }
    }
    if($is_duplication) {  
        $i--;
    }else{  
        array_push($arr, $val);
    }
}
print_r($arr);

// 간편한 풀이
for($i=0; $i<5; $i++){
    $val = rand(1,8);
    for($z=0; $z<count($arr); $z++){
        if($arr[$z] === $val) {
            $i--;
            goto first_for; // 이거 하면 countinue와 같은것.
        }
    }
    array_push($arr, $val); 
    first_for:
    $i++;
}
print_r($arr);


