<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <picture>
        <source media="(min-width: 700px)" srcset="https://i.picsum.photos/id/855/900/500.jpg?hmac=a6AJAQcwEnNpugugmoxtNLJMtW0dRcvKxkkUNe_BbSM">
        <source media="(min-width: 400px)" srcset="https://i.picsum.photos/id/120/500/300.jpg?hmac=XvmAI_MqIgGNPY9uGcw2_VfkuTxlpA9geHEW40R4ob0">
        <img src="https://i.picsum.photos/id/313/300/100.jpg?hmac=674ex8Z8rzpy2qVwGxBH6dUI28AiD6CtvyJQVEWmqYY" alt="People">
    </picture>
</body>
</html>