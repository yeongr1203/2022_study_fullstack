<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>부트스트랩_피규어</title>
</head>

<body>
    <div>
        <figure class="figure" style="width: 500px;">
            <img src="https://i.picsum.photos/id/146/500/300.jpg?hmac=fNhZnoVQ9JUxqt1xwhtat-R6yyuQ6FZI-OAOSP2FD2g" alt="...">
            <figcaption>A caption for the above image.</figcaption>
            <!-- figcaption은 block태그라 만약 부트스트랩사용하지 않는다면 figure값을 이미지와 맞춰서 따로 주면 img에 맞춰짐.  -->
        </figure>
    </div>
</body>

</html>