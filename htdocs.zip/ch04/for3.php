<?php
    for($i=1; $i<10; $i++)
    {
        for($z=1; $z<10; $z++)
        {
            print "i:${i}-z:${z} <br>";
        }
    print "----------<br>";
    }

?>

<!-- 

    밖에 for 문 = 시간
    안쪽 for 문 = 분
    으로 생각.
    = 안쪽 for 문dmf 밖 for문으로 반복하라






 -->