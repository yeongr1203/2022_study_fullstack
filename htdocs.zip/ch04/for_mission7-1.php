
<?php

   $star = rand(1,10);
    print "star값은 $star <br>";
   for ($i=$star; $i>0; $i--) // 원본은 건들지 말고.
   {
       print "*";
   }
   print "<br>";
?>
<!-- 

이건 $star값으로 시작하며, --(마이너스마이너스)를 사용해서 만든것.

-->



