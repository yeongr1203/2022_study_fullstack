<?php

    $dan = rand(2,9);
        for ( $i=1; $i<=9; $i++)
        {
            $dani = $dan * $i;
            print "$dan X $i = $dani <br>";
        }


// 쌤풀이

// for ( $i=1; $i<=9; $i++)
// {
// $result = $dan * $i;
// echo "$dan X $i = $result <br>";
// }
    
//학생풀이

    
?>
