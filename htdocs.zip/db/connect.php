<?php
    // error_log("test", 3, "./err.log");

    define("URL", "localhost");
    define("USERNAME", "root");
    define("PASSWORD", "506greendg@");
    define("DB_NAME", "board1");

    $conn = mysqli_connect(URL, USERNAME, PASSWORD, DB_NAME);   // 커넥션, 이것이 있어야 DB를 사용할 수 있다.
    // mysqli_connect = php에서는 무조건 있어야 함.
    // DB_NAME은 어떤 DB에 연결할지

    $sql = "INSERT INTO t_board(title, ctnt) 
    VALUES('반가워요2', 'nice to meet you2')";
    // VALUES('test', 'content')";
    // DB에서 사용하는 sql언어를 담아준다.

    // mysqli_query($conn, $sql);

    // conn라는 비행기에 sql언어를 담아서 지구에서 쏜다. DB에서 실행. 결과값까지 담아서 리턴되어 지구(PHP)로 날아온다.
    $result = mysqli_query($conn, $sql);
    // insert, delete,update문은 1 아니면 0, 1은 처리가 된것.

    print "result : $result";


    mysqli_close($conn);
    // 종료, 비행기를 뿌신다. 유지하면 유지비가 많이 나오기 때문에.
?>
<!-- 

    지구(PHP) =======> 별(DB)
    연결하는 비행기가 커넥션.
    커넥션을 만들어줘야 연결된다.
    지구에서 쓰는 언어 php, 별에서 쓰는 언어 sql


    1.(INSERT, UPDATE, DELETE) => 0 or 1 / 0 false, 1 true => 1인지 아닌지만 파악하면 끝.
    
    -- 2는 0개인지 1개인지 확인.
    2. SELECT - 최대1개 가져오는것!! 0 or 1개 (배열-행 1개)
    // 한페이지만 보고싶을때, detail페이지 작업시.
    // 게시판에서 detail페이지
    
    
    -- 3은 여러개 넘어올때 처리하는 방법
    3. SELECT - 여러개!!!! 0 or 1 or 2 => 배열(배열)
    // list page => 여러개 중에서 고를수있게.
    // 제목이 여러개니까 여러줄이 나타나야함.
    // 0이 들어갈 일이 언제냐? 없는 pk값이 들어갈때.
    // 1일 경우에는 무조건 한개만 들어감.

    1번만 돌리면 되기때문에 if문사용.

    2번과 3번의 차이점. // 대부분.
    2번은 where절에 pk가 들어감. and가 들어감. or은 안들어감.
    3번은 where절에 pk들어갈 일 없음.
    list에서는 반복문 사용. 

 -->