<?php

    // 내장함수들.

    print "abs(-3) : ". abs(-3) . "<br>";
    print "max([10,20,30]) : ". max([10,20,30]) . "<br>";
    // 함수([배열])
    print "min([10,20,30]) : ". min([10,20,30]) . "<br>";
    print "ceil(10.01) : ". ceil(10.01) . "<br>";
    print "ceil(10.00) : ". ceil(10.00) . "<br>";
    print "ceil(10.4) : ". ceil(10.4) . "<br>";
    print "ceil(10.) : ". ceil(10.6) . "<br>";
    print "floor(10.9) : ". floor(10.9) . "<br>";
    print "floor(10.01) : ". floor(10.01) . "<br>";
    print "pow(2,3) : " . pow(2,3) . "<br>";            //2의 3승
    print "sqrt(25) : " . sqrt(25) . "<br>";            // 25의 제곱근


?>

<!-- 

그나마 쓸만한 것들을 작성했음.
ceil을 페이징(게사판 아래 1,2,3,4 .. 그때 사용)하는 정도.
그나마 쓸만한 것들은 이정도.

웹개발자들은 잘 사용하지 않음.


 -->