<?php

$GLOBALS["foo"] = 10;

foreach($GLOBALS as $key => $var){
    // GLOBALS 배열이 php에 정의되어 있는
    print $key . ":";
    print_r($var);
    // 객체 및 문자를 찍을 땐 print_r
    // 객체는 print로 찍으면 에러.
    print "<br>";
}

$arr = [];
print_r($arr);
// print_r => 개발하다가 궁금할때 확인차원에서 주로 사용.


/*

    <?php
    //이미지 업로드할때 사용
    print __FILE__ . "<br>";
    print __LINE__ . "<br>";
    print __LINE__ . "<br>";
    print "PHP VERSION : " . PHP_VERSION . "<br>";
    print "OS : " . PHP_OS . "<br>";

    $GLOBALS["foo"] = 10;
    $GLOBALS["foo1"] = 11;

    print "-- 글로벌 상수 -- <br>";
    foreach($GLOBALS as $key => $var)
    {
        print $key . " : ";
        print_r($var);
        print "<br>";
    }

    $arr = array(
        "name" => "홍길동",
        "age" => 20,
        "height" => 160.6
    );
    foreach($arr as $key => $var)
    {
        print $key . " : ";
        print_r ($var);
        print "<br>";
    }
    phpinfo();
    ?>


*/