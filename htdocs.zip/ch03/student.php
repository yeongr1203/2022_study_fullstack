<?php
    $age = 21;
    $blood_type = 'O'; 
    $name = "Alice";

    print "나이 : $age<br>"; // 문자열에 변수값 사용됨. 자바는 사용이 안됨
    print "혈액형 : $blood_type<br>";
    print "이름 : $name<br>";

    // 문자열은 ""(쌍따옴표)로 사용. 홑따옴표쓰면 달라짐.
?>