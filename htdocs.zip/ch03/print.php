<?php
    print("Hello PHP");
    print "Hello PHP";
    
?>
<!-- 
    <div>태그 써도 들어간다. 하지만 그냥 html에서 구현하는게 좋음. php안에서는 php문법에 맞춰서 사용해야함.
    print("<div class=\"11\">Hello PHP<div>");
    역 슬러시\ 이거 로 감싸주고 안에 따옴표 숫자 함께 넣으면 쌍따옴표("") 나옴.
    \ 역슬러시 원화 표시가 맞음. 폰트에 따라 보여지는게 달라짐.
-->