<?php
    $n1=8;
    $n2=5;

    $result = $n1 + $n2 ;
    print " $n1 + $n2 = $result <br> ";

    $result = $n1 - $n2 ;
    print " $n1 - $n2 = $result <br> ";

    $result = $n1 * $n2 ;
    print " $n1 * $n2 = $result <br> ";

    $result = $n1 / $n2 ;
    print " $n1 / $n2 = $result <br> ";

    $result = $n1 % $n2 ;
    print " $n1 % $n2 = $result <br> ";
    //  % // modulo (모듀로) 라고함. 나머지 값 구할때 쓴다. 주로 홀짝 구분할때, 나머지 값을 구해서 나머지 연산이 필요할 때 사용함.
?>
