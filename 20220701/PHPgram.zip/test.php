<?php
require_once "application/utils/FileUtils.php";

$result = getRandomFileNum("asdfsaf.sdfsdf.jpg");


print $result;