<?php
namespace application\controllers;

// require_once "application/utils/UrlUtils.php";

class UserController extends Controller {
    // 로그인
    public function signin() {        
        switch(getMethod()) {
            case _GET:  // get방식일 경우 이렇게 처리가 될 것이다.
                return "user/signin.php";
            case _POST:
                // 아이디, 비밀번호가 하나라도 없거나 틀리면 => user/signin 리다이렉트
                // 아이디 비밀번호가 맞다면  /feed/index
                
                // 내 풀이
                // $param = [
                //     "email" => $_POST["email"],
                //     "pw" => $_POST["pw"]
                // ];
                // $result = $this->model->selUser($param);
                // if($result === false || !password_verify($param["pw"],$result->pw)) {
                //     return "user/signin.php";
                // }

                // 선생님풀이 
                $email = $_POST["email"];
                $pw = $_POST["pw"];
                $param = [ "email" => $email ];
                $dbUser = $this->model->selUser($param);    // selUser에 이 param을 보내줌.
                if(!$dbUser || !password_verify($pw,$dbUser->pw)) { // false라면 실행.
                    return "redirect:signin?mail={$email}&err"; // 쿼리스트링에 보낸 이메일주소&err 이라고 나타남.
                }  
                $dbUser->pw = null;     // 비밀번호를 굳이 들고 있지 않아도 되기 때문에.
                $dbUser->regdt = null;  // 해지. -> 메모리사용을 줄이기위해서 사용. // 이렇게 해도 되고 안해도 됨.
                $this->flash(_LOGINUSER,$dbUser);
                return "redirect:/feed/index";   // true일 때 사용.
                // 기존은 문자열 리턴, 컨트롤러에 보면     
        }        
    }   // 혹시나 리턴이나 객체로 리턴을 했다면, json실행.
    /* 
        sesson을 사용하는 이유? 스코프가 길다. 
        로그인 할때도 사용하지만, 
        이 화면에서 다른 화면으로 데이터 전달할 때도 사용할 수 있음. 
        화면을 끄지않으면 세션에 박힌 것을 사용할 수 있다.
    */

    //  회원가입
    public function signup() {  
        // print getMethod();

        // 호출이 2번 이루어 지기 때문에 switch가 더 효율적.
        // if(getMethod() === _GET) {
        //     return "user/signup.php";
        // } else if (getMethod() === _POST) {
        //     return "redirect:signin";
        // }
        switch(getMethod()) {
            case _GET:
                return "user/signup.php";
            case _POST:
                // i_user에 인서트하기.
                // 비밀번호는 암호화.
                $insPw = password_hash($_POST["pw"], PASSWORD_BCRYPT);
                $param = [
                    "email" => $_POST["email"],
                    "pw" => $insPw,
                    "nm" => $_POST["nm"]
                ];                
                $this->model->insUser($param);
                return "redirect:signin";
        }
    }

    // 아래는 처음에 선생님 테스트용.
    // public function signup() {
    //     $method = getMethod();
    //     switch($method) {
    //         case _GET:
    //             return;     
    //         case _POST:
    //             return;
    //     }
    // }

    // 로그아웃
    public function logout(){
        $this->flash(_LOGINUSER);
        return "redirect:/user/signin";
    }

    public function feedwin() {     // 여기 역시 로그인해야만 들어갈 수 있는 곳
        $iuser = isset($_GET["iuser"]) ? intval($_GET["iuser"]) : 0;
        // $param = [ "iuser" => $iuser ];
        $param = [ "feediuser" => $iuser , "loginiuser" => getIuser()];
        $this->addAttribute(_DATA, $this->model->selUserProfile($param));
        $this->addAttribute(_JS,["user/feedwin","https://unpkg.com/swiper@8/swiper-bundle.min.js"]);
        $this->addAttribute(_CSS,["user/feedwin","https://unpkg.com/swiper@8/swiper-bundle.min.css"]);
        // 여기는 템플릿사용.
        $this->addAttribute(_MAIN, $this->getView("user/feedwin.php"));
        return "template/t1.php";
    }

}