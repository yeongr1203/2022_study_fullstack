<?php
namespace application\models;
use PDO;


//$pdo -> lastInsertId();

class UserModel extends Model {
    public function insUser(&$param) {
        $sql = "INSERT INTO t_user
                ( email, pw, nm ) 
                VALUES 
                ( :email, :pw, :nm )";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":email", $param["email"]);
        $stmt->bindValue(":pw", $param["pw"]);
        $stmt->bindValue(":nm", $param["nm"]);
        $stmt->execute();
        return $stmt->rowCount();

    }
    
    public function selUser(&$param) {
        $sql = "SELECT * FROM t_user
                WHERE email = :email";  // 받은 param을 집어 넣을 것이다.
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":email", $param["email"]);        
        $stmt->execute();   // 실행함.
        return $stmt->fetch(PDO::FETCH_OBJ);    // 실행 결과값을 리턴.
    }
    
    // public function selUserByIuser(&$param) {
    //     $sql = "SELECT iuser, email, nm, cmt, mainimg, regdt 
    //                FROM t_user
    //               WHERE iuser = :iuser";
    //     $stmt = $this->pdo->prepare($sql);
    //     $stmt->bindValue(":iuser", $param["iuser"]);
    //     $stmt->execute();
    //     return $stmt->fetch(PDO::FETCH_OBJ);
    // }

    // usercontroller에서 selUserByIuser 를 selUserProfile로 변경.
    public function selUserProfile(&$param) {
        $feediuser = $param["feediuser"];
        $loginiuser = $param["loginiuser"];
        $sql = 
        "SELECT iuser, email, nm, cmt, mainimg
                , (SELECT COUNT(ifeed) FROM t_feed WHERE iuser = {$feediuser}) AS feedCnt
                , (SELECT COUNT(fromiuser) FROM t_user_follow WHERE fromiuser = {$feediuser} AND toiuser = {$loginiuser} ) AS youme
        		, (SELECT COUNT(fromiuser) FROM t_user_follow WHERE fromiuser = {$loginiuser} AND toiuser = {$feediuser} ) AS meyou
                , (SELECT COUNT(fromiuser) FROM t_user_follow WHERE toiuser = {$feediuser} ) AS f_me
                , (SELECT COUNT(toiuser) FROM t_user_follow WHERE fromiuser = {$loginiuser} ) AS f_you
        FROM t_user
        WHERE iuser= {$feediuser}  
        ";
        // 물음표는 순서. 물음표 순서대로 값이 들어감.
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        // bindValue지우기고 아래행 실행하면 동일함.
        // $stmt->execute(array($param["iuser"],$param["iuser"]));
        return $stmt->fetch(PDO::FETCH_OBJ);
    }
}