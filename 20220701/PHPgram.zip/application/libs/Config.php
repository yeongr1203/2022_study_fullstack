<?php
    define("_SERVICE_NM", "PHPgram");
    define('_ROOT', $_SERVER['DOCUMENT_ROOT']);
    define('_DBTYPE', 'mysql'); //mysql, mariadb 등
    define('_DBHOST', 'localhost'); //DB접속 주소
    define('_DBNAME', 'phpgram'); //DB명
    define('_DBUSER', 'root'); //아이디
    define('_DBPASSWORD', '506greendg@'); //비번
    define('_CHARSET', 'utf8');
    define("_VIEW", "application/views/");

    define("_HEADER", "header");
    define("_MAIN", "main");
    define("_FOOTER", "footer");

    define("_CSS", "css");
    define("_JS", "js");

    define("_LOGINUSER", "loginUser");  // 로그인세션

    define("_LIST", "list");
    define("_DATA", "data");
    define("_ITEM", "item");
    define("_RESULT", "result");

    define("_POST", "POST");
    define("_GET", "GET");
    define("_PUT", "PUT");
    define("_DELETE", "DELETE");
    
    define("_IMG_PATH", "static/img");     // 이미지저장공간 => 상수로 지정.
    define("_FEED_ITEM_CNT", 20);
    