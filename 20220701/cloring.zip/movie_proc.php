<?php
    //python 실행 파일 경로입력 후 파일 위치 적기!!!!
    exec('C:\Users\Administrator\AppData\Local\Programs\Python\Python310\python.exe test.py');
    header("Location: movie.php")
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <input id="btn_test" type="button" value="영화순위보기">
    <div id="result"></div>
    <script>
        const btn = document.querySelector('#btn_test');
        const result = document.querySelector('#result');
        // btn.addEventListener('click', function() {
        //     const url = '\Apache24\htdocs\test.py';
        //     fetch(url).then(function(res){
        //         return res.json();
        //     }).then(function(date) {
        //         console.log(parse_str(data));
        //     });
        //     exec(url);
        // });

        // function makeList(date) {
        //     data.foreach(function(item) {
        //         const div = document.createElement('div');
        //         div.innerText = item;
        //         result.appendChild(div);
        //     })
        // }
    </script>

</body>
</html>

