import requests
from bs4 import BeautifulSoup

print("test.py")

url = 'https://movie.naver.com/movie/running/current.naver'
response = requests.get(url)
html = response.text
soup = BeautifulSoup(html, 'html.parser')

movie_list = soup.find_all('div', class_='thumb')

f = open('./movie.txt', 'w', encoding='utf-8')
for movie in movie_list:
    a_href = movie.find('img')['src']
    a_ctn = movie.find('img')['alt']

    f.write(a_href)
    f.write(',')
    f.write(a_ctn)
    f.write('\n')
f.close() 